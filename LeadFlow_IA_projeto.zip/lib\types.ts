export type PipelineStage =
  | "Novo Lead"
  | "Contato iniciado"
  | "Resposta recebida"
  | "Reunião"
  | "Proposta enviada"
  | "Negociação"
  | "Cliente"
  | "Perdido";

export type Lead = {
  id: number;
  name: string;
  niche: string;
  city: string;
  state: string;
  instagram: string | null;
  website: string | null;
  whatsapp: string | null;
  followers: number | null;
  google_rating: number | null;
  google_reviews: number;
  has_site: number;
  lead_score: number;
  status: string;
  pipeline_stage: PipelineStage;
  created_at: string;
};

export type BestLeadsResponse = {
  total: number;
  filters: {
    limit: number;
    city: string | null;
    niche: string | null;
    min_score: number;
    without_site: boolean;
    without_instagram: boolean;
    status: string | null;
    pipeline_stage: string | null;
  };
  results: Lead[];
};